import streamlit as st
import pandas as pd
import numpy as np
import PyPDF2
import os
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
import nltk
from nltk.corpus import stopwords
from gensim.parsing.preprocessing import STOPWORDS

# Load pre-trained model
import pickle
with open("resume_classifier.pkl", "rb") as f:
    model, vectorizer = pickle.load(f)
# Function to extract text from PDF
def extract_text_from_pdf(pdf_file):
    pdf_reader = PyPDF2.PdfReader(pdf_file)
    text = ""
    for page in pdf_reader.pages:
        text += page.extract_text() + " "
    return text.strip()

# Function to clean and preprocess text
def preprocess(text):
    stop_words = set(stopwords.words("english")).union(STOPWORDS)
    words = text.lower().split()
    words = [word for word in words if word not in stop_words and len(word) > 2]
    return " ".join(words)

# Streamlit UI
st.title("Resume Classifier")
st.write("Upload a resume (PDF or TXT) to classify it.")

uploaded_file = st.file_uploader("Upload Resume", type=["pdf", "txt"])

if uploaded_file:
    if uploaded_file.type == "application/pdf":
        resume_text = extract_text_from_pdf(uploaded_file)
    else:
        resume_text = uploaded_file.read().decode("utf-8")

    cleaned_text = preprocess(resume_text)
    transformed_text = vectorizer.transform([cleaned_text])

    prediction = model.predict(transformed_text)[0]
    result = "Flagged" if prediction == 1 else "Not Flagged"

    st.subheader("Classification Result:")
    st.write(f"**{result}**")

    st.subheader("Resume Preview:")
    st.text_area("Resume Content", resume_text, height=300)
