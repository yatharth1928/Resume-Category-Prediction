import textblob
print(textblob.__file__)

